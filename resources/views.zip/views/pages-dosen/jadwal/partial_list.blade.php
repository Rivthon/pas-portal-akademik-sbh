@foreach($jadwalList as $semester => $jadwalSemester)
<div class="mb-4">
    <h5 class="fw-bold text-primary">Semester {{ $semester }}</h5>
    <div class="row">
        @foreach($jadwalSemester as $jadwal)
        <div class="col-md-4">
            <div class="card shadow-sm mb-3 bg-primary text-white">
                <div class="card-body">
                    <h6 class="card-title fw-bold text-white">
                        {{ $jadwal['nama_matakuliah'] }}
                        <span class="badge bg-secondary ms-2">{{ $jadwal['kode_matakuliah'] ?? '-' }}</span>
                    </h6>
                    <p class="text-white-50 mb-2"><i class="bi bi-calendar-event"></i> {{ $jadwal['hari'] }}</p>
                    <p class="mb-1">
                        <i class="bi bi-clock"></i> {{ $jadwal['jam_mulai'] }} - {{ $jadwal['jam_selesai'] }}
                    </p>
                    <p class="mb-1"><i class="bi bi-person-badge"></i> Dosen:</p>
                    <ul class="list-unstyled">
                        @foreach($jadwal['dosen'] as $dosen)
                        <li>
                            <i class="bi bi-dot"></i> {{ $dosen['nama'] }}
                            <span class="badge bg-info text-dark ms-2">{{ ucfirst($dosen['jenis_dosen']) }}</span>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endforeach