@extends('layouts.master')

@section('content')
<div class="card shadow-sm mb-4">
    <div class="d-flex align-items-center item g-0">
        <!-- Content Section -->
        <div class="col-md-7">
            <div class="card-body">
                <!-- Title -->
                <h5 class="card-title text-primary mb-3 fw-bold">
                    Trankrip Nilai Mahasiswa
                </h5>
                <!-- Description -->
                <p class="mb-4 text-muted" style="line-height: 1.6;">
                    Pastikan Anda telah memilih program studi
                    dan semester yang bersangkutan. Kemudian pilih mahasiswa yang ingin Anda lihat nilai transkripnya.
                </p>

            </div>
        </div>
        <!-- Image Section -->
        <div class="col-md-5 text-center">
            <div class="p-3">
                <img src="{{ asset('assets/img/illustrations/nilai.png') }}" class="img-fluid"
                    alt="Illustration of a schedule" style="max-height: 200px;">
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="container mt-4 mb-4">
        <div>
            <h5>Pilih Program Studi</h5>
            <select id="program-studi" class="form-select">
                <option value="">-- Pilih Program Studi --</option>
                @foreach ($programStudi as $ps)
                <option value="{{ $ps->jurusan_id }}">{{ $ps->nama }}</option>
                @endforeach
            </select>

            <h5 class="mt-4">Pilih Semester</h5>
            <select id="semester" class="form-select">
                <option value="">-- Pilih Semester --</option>
                @for ($i = 1; $i <= 8; $i++) <option value="{{ $i }}">Semester {{ $i }}</option>
                    @endfor
            </select>

            <h5 class="mt-4">Pilih Mahasiswa</h5>
            <select id="mahasiswa" class="form-select" disabled>
                <option value="">-- Pilih Mahasiswa --</option>
            </select>

            <h5 class="mt-4">Data KRS Mahasiswa</h5>
            <table id="krs-table" class="table table-bordered mt-3" style="display: none;">
                <thead class="table-primary">
                    <tr>
                        <th>Semester</th>
                        <th>Nama Mata Kuliah</th>
                        <th>KHS</th>
                        <th>UTS</th>
                        <th>UAS</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data akan diisi dengan AJAX -->
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const programStudiSelect = document.getElementById('program-studi');
    const semesterSelect = document.getElementById('semester');
    const mahasiswaSelect = document.getElementById('mahasiswa');
    const krsTable = document.getElementById('krs-table');
    const krsTableBody = krsTable.querySelector('tbody');

    // Fungsi reusable untuk mengambil data dari API
    const fetchData = async (url, onSuccess, onError) => {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error("Gagal memuat data dari server.");
            const data = await response.json();
            onSuccess(data);
        } catch (error) {
            console.error(error);
            if (onError) onError(error.message);
        }
    };

    // Fungsi untuk mengambil data mahasiswa
    const fetchMahasiswa = () => {
        const prodiId = programStudiSelect.value; // ID Program Studi
        const semester = semesterSelect.value; // Semester yang dipilih

        if (!prodiId || !semester) {
            mahasiswaSelect.innerHTML = '<option value="">-- Pilih Mahasiswa --</option>';
            mahasiswaSelect.disabled = true;
            return;
        }

        const url = `/admin/api/mahasiswa-by-prodi-semester?jurusan_id=${prodiId}&semester=${semester}`;
        fetchData(
            url,
            (data) => {
                mahasiswaSelect.innerHTML = '<option value="">-- Pilih Mahasiswa --</option>';
                if (data.length > 0) {
                    data.forEach((mahasiswa) => {
                        const option = `<option value="${mahasiswa.mahasiswa_id}">${mahasiswa.nama}</option>`;
                        mahasiswaSelect.insertAdjacentHTML('beforeend', option);
                    });
                    mahasiswaSelect.disabled = false;
                } else {
                    mahasiswaSelect.innerHTML = '<option value="">Tidak ada mahasiswa</option>';
                    mahasiswaSelect.disabled = true;
                }
            },
            () => {
                alert("Terjadi kesalahan saat memuat data mahasiswa. Silakan coba lagi.");
                mahasiswaSelect.innerHTML = '<option value="">-- Pilih Mahasiswa --</option>';
                mahasiswaSelect.disabled = true;
            }
        );
    };

    // Fungsi untuk mengambil data KRS
    const fetchKRS = () => {
        const mahasiswaId = mahasiswaSelect.value; // ID Mahasiswa yang dipilih

        if (!mahasiswaId) {
            krsTable.style.display = 'none';
            return;
        }

        const url = `/admin/api/krs-mahasiswa/${mahasiswaId}`;
        fetchData(
            url,
            (data) => {
                krsTableBody.innerHTML = ''; // Bersihkan tabel sebelumnya
                if (data.status === "success" && data.data.length > 0) {
                    krsTable.style.display = ''; // Tampilkan tabel
                    data.data.forEach((krs) => {
                        const row = `
                            <tr>
                                <td>${krs.smt}-${krs.semester}</td>
                                <td>${krs.nama_mata_kuliah}</td>
                                <td>${krs.khs || '-'}</td>
                                <td>${krs.uts || '-'}</td>
                                <td>${krs.uas || '-'}</td>
                            </tr>`;
                        krsTableBody.insertAdjacentHTML('beforeend', row);
                    });
                } else {
                    krsTable.style.display = 'none';
                    alert(data.message || "Data KRS tidak ditemukan.");
                }
            },
            () => {
                alert("Terjadi kesalahan saat memuat data KRS. Silakan coba lagi.");
                krsTable.style.display = 'none';
            }
        );
    };

    // Event listeners
    programStudiSelect.addEventListener('change', fetchMahasiswa);
    semesterSelect.addEventListener('change', fetchMahasiswa);
    mahasiswaSelect.addEventListener('change', fetchKRS);
});

    // Fungsi untuk menampilkan pesan pada tabel
</script>