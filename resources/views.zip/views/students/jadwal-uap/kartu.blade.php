<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Ujuan Akhir Praktik</title>
    @php
    $settings = \App\Models\Setting::first();
    @endphp
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            /* Ganti Arial dengan Times New Roman */

            font-size: 12px;
            /* Ukuran font diseragamkan menjadi 12px */
        }

        /* Header styling */
        .header {
            text-align: center;
            /* Mengatur semua elemen header agar rata tengah */
            padding: 20px 30px;
            background-color: #ffffff;
            /* Putih bersih */
            border-bottom: 2px solid #e0e0e0;
            /* Garis bawah untuk pembatas */
        }

        .logo-container {
            margin-bottom: 15px;
            /* Jarak antara logo dan teks */
        }

        .logo {
            max-width: 80px;
            height: auto;
        }

        .header-text {
            margin: 0 auto;
            /* Untuk memastikan tetap di tengah */
        }

        .title {
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            color: #333;
        }

        .subtitle {
            font-size: 1.2rem;
            margin: 5px 0 0;
            color: #666;
        }

        /* Info table styling */
        .info {
            margin: 20px 30px;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 1rem;
            color: #333;
        }

        .info-table th,
        .info-table td {
            text-align: left;
            padding: 10px 15px;
        }

        .info-table th {
            width: 25%;
            font-weight: bold;
            background-color: #f8f8f8;
            /* Warna latar untuk header kolom */
        }

        .info-table td {
            background-color: #ffffff;
            /* Putih bersih */
        }

        .info-table tr:nth-child(even) td {
            background-color: #f9f9f9;
            /* Striping pada baris genap */
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;

        }

        .table th,
        .table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }

        .footer {
            margin-top: 30px;
            text-align: right;
            /* Posisi tanda tangan di sebelah kanan */
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
        }

        .info-table th,
        .info-table td {
            padding: 5px;
            text-align: left;
        }

        .info-table th {
            color: black;
            /* Warna teks header */
        }
    </style>
</head>
<div class="header">
    @if($logoBase64)
    <div class="logo-container">
        <img src="data:image/png;base64,{{ $logoBase64 }}" alt="Logo" class="logo">
    </div>
    @endif
    <div class="header-text">
        <h1 class="title">Kartu Ujian Akhir Praktik</h1>
        <h3 class="subtitle">{{ $activeTA->nama }} - {{ $activeTA->semester }}</h3>
    </div>
</div>
<div class="info">
    <table class="info-table">
        <tr>
            <th>Nama</th>
            <td>{{ auth('mahasiswa')->user()->nama }}</td>
            <th>NIM</th>
            <td>{{ auth('mahasiswa')->user()->nim }}</td>
        </tr>
        <tr>
            <th>Prog. Studi</th>
            <td>{{ auth('mahasiswa')->user()->programStudi->nama }}</td>
            <th>Semester</th>
            <td>{{ auth('mahasiswa')->user()->semester }}</td>
        </tr>
    </table>
</div>

<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Mata Kuliah</th>
            <th>SKS</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Ruangan</th>
        </tr>
    </thead>
    <tbody>
        @foreach($jadwalUap as $key => $item)
        <tr>
            <td>{{ $key + 1 }}</td>
            <td>{{ $item->mataKuliah->nama }}</td>
            <td>{{ $item->mataKuliah->sks }}</td>
            <td>{{ \Carbon\Carbon::parse($item->tanggal)->translatedFormat('d F Y') }}</td>
            <td>{{ $item->jam }}</td>
            <td>{{ $item->ruangan->nama ?? 'Tidak ada data' }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

<div class="footer">
    <strong style="display: block; text-align: left; font-weight: bold; margin-bottom: 10px;">Perhatian:</strong>
    <ul style="text-align: left; font-weight: bold;">
        <li>Peserta Ujian wajib menggunakan atribut lengkap</li>
        <li>Untuk PRODI Kebidanan menggunakan Seragam dan Name Tag</li>
        <li>Untuk PRODI Farmasi & Gizi Menggunakan Almamater dan Name Tag</li>
        <li>Membawa alat tulis sendiri</li>
        <li>Kartu Ujian ini wajib dibawa setiap pelaksanaan ujian</li>
    </ul>

    <div style="text-align: right; margin-top: 30px;">
        <p>Ketua Program Studi

        </p>
        @if ($ttd)
        <img src="data:image/png;base64,{{ $ttd }}" alt="Tanda Tangan Kaprodi" style="height: 60px;">
        @else
        <div class="placeholder"></div>
        @endif
        <p>
            {{ auth('mahasiswa')->user()->programStudi->kaprod }}
        </p>
    </div>
</div>