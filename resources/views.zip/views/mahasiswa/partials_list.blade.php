<div class="row">
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>Avatar</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>NIM</th>
                    <th>Program Studi</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($mahasiswa as $m)
                <tr>
                    <td>
                        <img src="{{ $m->avatar_url }}" alt="Avatar" class="rounded-circle border"
                            style="width: 40px; height: 40px; object-fit: cover;"
                            onerror="this.src='{{ asset('dashboard_assets/assets/img/avatars/1.png') }}'" />
                    </td>
                    <td>{{ $m->nama }}</td>
                    <td>{{ $m->email }}</td>
                    <td>{{ $m->nim }}</td>
                    <td>{{ $m->programStudi->nama ?? '-' }}</td>
                    <td>
                        @php
                        $statusColors = [
                        'aktif' => 'success',
                        'nonaktif' => 'danger',
                        'lulus' => 'primary',
                        'dropout' => 'warning',
                        'cuti' => 'info',
                        ];
                        @endphp
                        <span class="badge bg-{{ $statusColors[$m->status_mhs] ?? 'secondary' }}">
                            {{ ucfirst($m->status_mhs) }}
                        </span>
                        <form action="{{ route('admin.mahasiswa.updateStatus', $m->mahasiswa_id) }}" method="POST"
                            class="mt-1">
                            @csrf
                            @method('PUT')
                            <select name="status_mhs" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="aktif" {{ $m->status_mhs === 'aktif' ? 'selected' : '' }}>Aktif
                                </option>
                                <option value="nonaktif" {{ $m->status_mhs === 'nonaktif' ? 'selected' : ''
                                    }}>Nonaktif</option>
                                <option value="lulus" {{ $m->status_mhs === 'lulus' ? 'selected' : '' }}>Lulus
                                </option>
                                <option value="dropout" {{ $m->status_mhs === 'dropout' ? 'selected' : ''
                                    }}>Dropout</option>
                                <option value="cuti" {{ $m->status_mhs === 'cuti' ? 'selected' : '' }}>Cuti
                                </option>
                            </select>
                        </form>
                    </td>
                    <td>
                        @can('mahasiswa-edit')
                        <a class="btn btn-primary btn-sm mb-1"
                            href="{{ route('admin.mahasiswa.edit', $m->mahasiswa_id) }}" data-bs-toggle="tooltip"
                            data-bs-original-title="Edit Mahasiswa">
                            <i class="bx bx-edit"></i>
                        </a>
                        @endcan

                        @can('mahasiswa-delete')
                        <form action="{{ route('admin.mahasiswa.destroy', $m->mahasiswa_id) }}" method="POST"
                            style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm mb-1"
                                onclick="return confirm('Apakah Anda yakin?')" data-bs-toggle="tooltip"
                                data-bs-original-title="Hapus Mahasiswa">
                                <i class="bx bx-trash"></i>
                            </button>
                        </form>
                        @endcan

                        <form action="{{ route('admin.resetPassword', $m->mahasiswa_id) }}" method="POST"
                            style="display:inline;">
                            @csrf
                            <button type="submit" class="btn btn-warning btn-sm mb-1"
                                onclick="return confirm('Reset password mahasiswa ini?')" data-bs-toggle="tooltip"
                                data-bs-original-title="Reset Password">
                                <i class="bx bx-reset"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center text-muted">Tidak ada data ditemukan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@if ($mahasiswa->hasPages())
<div class="d-flex justify-content-center mt-3 pagination-links">
    {{ $mahasiswa->links('pagination::bootstrap-4') }}
</div>
@endif