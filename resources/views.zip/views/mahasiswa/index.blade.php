@extends('layouts.master')
@section('title', 'Data Mahasiswa')
@section('content')
<div class="card shadow-sm mb-4">
    <div class="d-flex align-items-center row g-0">
        <!-- Content Section -->
        <div class="col-md-8">
            <div class="card-body">
                <!-- Title -->
                <h5 class="card-title text-primary mb-3 fw-bold">
                    Data Mahasiswa
                </h5>
                <!-- Description -->
                <p class="mb-4 text-muted" style="line-height: 1.6;">
                    Berikut adalah daftar mahasiswa yang terdaftar di sistem. Anda dapat melakukan import data mahasiswa
                    dengan mengunggah file excel yang berisi data mahasiswa.
                </p>
                <!-- CTA Button -->
                <div class="mb-3">
                    <!-- Import Form -->
                    <form action="{{ route('admin.mahasiswa.import') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <!-- File Upload Section -->
                        <div class="row mb-4">
                            <div class="col-md-8">
                                <label for="file" class="form-label fw-bold">Upload File Excel</label>
                                <div class="input-group">
                                    <input type="file" name="file" id="file" class="form-control" required>
                                    <label class="input-group-text" for="file">Choose file</label>
                                </div>
                                <small class="text-muted">Pastikan file berformat .xlsx atau .csv</small>
                            </div>
                        </div>

                        <!-- Submit and Download Buttons on the Same Row -->
                        <div class="row">
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-success w-100">
                                    <i class="fa fa-upload"></i> Import Mahasiswa
                                </button>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <a href="{{ route('admin.mahasiswa.download-template') }}"
                                    class="btn btn-outline-info w-100">
                                    <i class="fa fa-download"></i> Download Contoh File
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Image Section -->
        <div class="col-md-4 text-center">
            <div class="p-3">
                <img src="../assets/img/illustrations/mahasiswa-2.png" class="img-fluid"
                    alt="Illustration of a schedule" style="max-height: 200px;">
            </div>
        </div>
    </div>
</div>
<div class="card mt-5">
    <div class="container mt-5">
        <h5 class="mb-4">Cari Mahasiswa</h5>
        <!-- Form Pencarian dengan AJAX -->
        <form id="search-form" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" id="search-mahasiswa" class="form-control"
                    placeholder="Cari nama, NIM, atau program studi" value="{{ request()->get('search') }}">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </form>

        <!-- Wrapper List Mata Kuliah -->
        <div id="mahasiswa-list">
            @include('mahasiswa.partials_list', ['mahasiswa' => $mahasiswa])
        </div>

    </div>
    @endsection